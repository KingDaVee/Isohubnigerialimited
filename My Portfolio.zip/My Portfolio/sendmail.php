
<?php

$un=$_POST['name'];
$em=$_POST['email'];
$su=$_POST['subject'];
$msg=$_POST['message'];
if(trim($un)!="" && trim($msg)!="" && trim($su)!="" && trim($em)!="")

	if(filter_var($em, FILTER_VALIDATE_EMAIL))
	
		$message="Hi Admin..<p><b>".$un."</b> sent a message".$su."email id as ".$em."</p><p>Query is : ".$msg."</p>";
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: <>' . "\r\n";

		if(mail('Isohub.coded@gmail.com','Query for Isohub',$message,$headers ))
		{
		    header('Location: index.html');
		}
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			// Collect form data
			$name = strip_tags(trim($_POST["name"]));
			$phone = strip_tags(trim($_POST["phone"]));
			$email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
			$message = trim($_POST["message"]);
		
			// Check data
			if (empty($name) OR empty($message) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
				// Set a 400 (bad request) response code and exit.
				http_response_code(400);
				echo "Oops! There was a problem with your submission. Please complete the form and try again.";
				exit;
			}
		
			// Recipient email address
			$recipient = "Isohub.coded@gmail.com"; // Replace with your email
		
			// Email subject
			$subject = strip_tags(trim($_POST["subject"]));
		
			// Email content with table format
			$email_content = "
			<html>
			<head>
				<style>
					table {
						border-collapse: collapse;
						width: 100%;
					}
					th, td {
						border: 1px solid #ddd;
						padding: 8px;
					}
					th {
						background-color: #f2f2f2;
					}
				</style>
			</head>
			<body>
				<table>
					<tr>
						<th>Name</th>
						<td>$name</td>
					</tr>
					<tr>
						<th>Email</th>
						<td>$email</td>
					</tr>
					<tr>
						<th>Subject</th>
						<td>$subject</td>
					</tr>
					<tr>
						<th>Message</th>
						<td>$message</td>
					</tr>
				</table>
			</body>
			</html>
			";
		
			// Email headers
			$email_headers = "From: $name <$email>\r\n";
			$email_headers .= "MIME-Version: 1.0\r\n";
			$email_headers .= "Content-Type: text/html; charset=UTF-8\r\n";
		
			// Send the email
			if (mail($recipient, $subject, $email_content, $email_headers)) {
				// Set a 200 (okay) response code.
				http_response_code(200);
				header ("location: index.html" );
			} else {
				// Set a 500 (internal server error) response code.
				http_response_code(500);
				echo "Oops! Something went wrong, and we couldn't send your message.";
			}
		} else {
			// Not a POST request, set a 403 (forbidden) response code.
			http_response_code(403);
			echo "There was a problem with your submission, please try again.";
		}
		
		$name = $_POST['name'];
		$email = $_POST['email'];
		 $subject = $_POST['subject'];
		 $message = $_POST['message'];  
	
	 $sql = "INSERT INTO contact_me (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";
	
	
	 if ($conn->multi_query($sql) === TRUE) {
	 } else {     echo "Error: " . $sql . "<br>" . $conn->error;
	 }
	 header("Location: thank_you.php", true, 301);  
	exit(); 
	$conn->close();
	?>

